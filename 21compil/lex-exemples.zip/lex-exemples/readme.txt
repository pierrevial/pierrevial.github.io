Utiliser lex rapidement                (pierre.vial@inria.fr)

1) Principes

a) extension: Les fichiers d'analyse lexicale terminent par l'extension ".l"

b) lex puis compilation
  - La commande "lex nom_de_fichier.l -lfl" produit un fichier C appelé invariablement "lex.yy.c"
 - Le fichier contient une fonction d'analise lexicale appelée "yylex"
 - L'option "-lfl" permet d'appeler les bibliothèques lex

c) exécution:
  - on peut exécuter le fichier produit (s'appelant en principe "a.out") en écrivant ./a.out
  - "./a.out" va appliquer l'analyse lexicale (définie par le fichier lex) à l'entrée standard
  - "./a.out < autre_fichier" va applique l'analyse lexicale au fichier nommé "autre_fichier"

Exemple:
- Aller dans le répertoire "01playingwithlex"
- Entrer "lex priolex.l"
- Entrer "gcc lex.yy.c -lfl"
- Entrer "./a.out" puis entrer du texte
- Entrer "./a.out loremipsum.txt"


2) Les fichiers:

a) 4 sous-répertoires (à lire dans l'ordre en principe) contenant chacun un fichier lex (*.l)

b) dans chacun, "lex nom_de_fichier.l" puis "gcc lex.yy.c -lfl" puis "./a.out"

c) En fin de chaque fichier lex, on trouve en commentaire des suggestions de tests (mots à taper dans l'entrée standard)

d) Cette archive s'enrichira au fur et à mesure que le cours avancera !


3) Tables des matières

01playingwithlex: règles de traduction, code dans le langage cible, priorités (lex est gourmant, etc)

02regexes : demander à lex de reconnaître des expressions régulières, le caractere d'echappement \

03declas : déclarations de macros

04variableslex : variables spéciales de lex: yytext, yyleng, yylineno, qui permettent de récuperer et traiter le lexème courant (inachevé)
